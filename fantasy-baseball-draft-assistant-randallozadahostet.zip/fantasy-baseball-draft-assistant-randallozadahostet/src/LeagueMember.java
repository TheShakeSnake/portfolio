
import java.io.Serializable;

public class LeagueMember implements Serializable{
Team team;
String label;
public LeagueMember(String label) {
	team = new Team();
	this.label = label;
}

public void addTeamMember(Batter member) {
	if(member.drafted) {
		System.out.println("Player has already been drafted, pick another and try again");
	}
	else {
		switch(member.position) {
		case C:
			team.setCatcher(member);
			break;
		case B1:
			team.setFirstBase(member);
			break;
		case B2:
			team.setSecondBase(member);
			break;
		case B3:
			team.setThirdBase(member);
			break;
		case SS:
			team.setShortStop(member);
			break;
		case LF:
			team.setLeftField(member);
			break;
		case CF:
			team.setCenterField(member);
			break;
		case RF:
			team.setRightField(member);
			break;
		default:
			System.out.println("Error with adding member to a team");
			
		}
		
	}

}
public void addTeamMember(Pitcher member) {
	if(member.drafted) {
		System.out.println("Pitcher has been drafted already, select a new one and try again");
	}
	team.addPitcher(member);
}
public void removeTeamMember(Batter member) {
		member.drafted = false;
	
	switch(member.position) {
		case C:
			team.setCatcher(null);
			break;
		case B1:
			team.setFirstBase(null);
			break;
		case B2:
			team.setSecondBase(null);
			break;
		case B3:
			team.setThirdBase(null);
			break;
		case SS:
			team.setShortStop(null);
			break;
		case LF:
			team.setLeftField(null);
			break;
		case CF:
			team.setCenterField(null);
			break;
		case RF:
			team.setRightField(null);
			break;
		default:
			System.out.println("Error with removing a member from the team");
			
		}
}
public void removeTeamMember(Pitcher member) {
	team.removePitcher(member);
}
}
