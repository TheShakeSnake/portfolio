
import java.io.File;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// import com.sun.beans.introspect.PropertyInfo.Name;


public class FantasyMatch implements Serializable{
	HashMap<String,Batter>batters;
	HashMap<String,Pitcher>pitchers;
	ArrayList<String> batterkeys;
	ArrayList<String> pitcherkeys;
	LeagueMember a,b,c,d;
	String batterExp = "AVG";
	String pitcherExp = "IP";
	
	public FantasyMatch() {
		batters = new HashMap<String,Batter>();
		pitchers = new HashMap<String,Pitcher>();
		batterkeys = new ArrayList<>();
		pitcherkeys = new ArrayList<>();
		
		a = new LeagueMember("a");
		b = new LeagueMember("b");
		c = new LeagueMember("c");
		d = new LeagueMember("d");
		
		File pitcherFile = new File("data/pitchers.txt");
		File batterFile = new File("data/batters.txt");
		Scanner s;
		int top50 = 1;
		try {
			s = new Scanner(pitcherFile);
			Scanner batscan = new Scanner(batterFile);
			s.nextLine();
			batscan.nextLine();
			   //read from csv to poplate batter db
			 while (batscan.hasNextLine()) {
			        String data = batscan.nextLine();
			       //removes * from the player's name if it has one in the csv
			        if(data.contains("*")) {
			        	data = data.replace("*", "");
			        }
			        String[] dataArr = data.split(",", -1);
			        //turns out the batters list has pitchers on it too... we have a seperate csv for those with stats that pertain more to them,
			        //so we are gonna ignore them for the batter list
			        //takes the character that pertains to the players position on the field
			        char poschar = dataArr[28].charAt(0);
			        //if the character that it grabs is a /, it should grab the next character 
			        if(poschar == '/') {
			        	poschar = dataArr[28].charAt(1);
			        }
			    	String aString = poschar + "";
			    	//if the position is 1, the player is a pitcher, if it pulls a D, the player is a designated hitter, H is a pinch hitter
			    	//pitchers are entered into a seperate table below
			    	//designated hitters are to be ignored, I'm assuming it's the same for pinch hitters?
			    	if(poschar == '1' || poschar == 'D'|| poschar == 'H') {
			    		top50++;
			    		continue;
			    	}
			        //checks for empty strings in the array
			        //was encountering issues with double values being blank in the csv file, this just fills them in with 0s to avoid a 
			        //NumberFormatException
			        for(int i = 0; i < dataArr.length; i++) {
			        	if(dataArr[i].isEmpty()) {
			        		dataArr[i] = "0";
			        	}
			        }
			        //some of the pos summaries dont actually have the position number in them, luckilly this doesnt happen until #51
			        //we only need the top 50 for our first sprint
			        //this will only grab the top 50 players
			        
			        
			        int rank = Integer.parseInt(dataArr[0]);
			        String name = dataArr[1];
			        int age = Integer.parseInt(dataArr[2]);
			        String team = dataArr[3];
			        int G = Integer.parseInt(dataArr[4]);
			        int PA = Integer.parseInt(dataArr[5]);
			        int AB = Integer.parseInt(dataArr[6]);
			        int R = Integer.parseInt(dataArr[7]);
			        int H = Integer.parseInt(dataArr[8]);
			        int B2 = Integer.parseInt(dataArr[9]);
			        int B3 = Integer.parseInt(dataArr[10]);
			        int HR = Integer.parseInt(dataArr[11]);
			        int RBI = Integer.parseInt(dataArr[12]);
			        int SB = Integer.parseInt(dataArr[13]);
			        int CS = Integer.parseInt(dataArr[14]);
			        int BB = Integer.parseInt(dataArr[15]);
			        int SO = Integer.parseInt(dataArr[16]);
			        double BA = Double.parseDouble(dataArr[17]);
			        double OBP = Double.parseDouble(dataArr[18]);
			        double SLG = Double.parseDouble(dataArr[19]);
			        double OPS = Double.parseDouble(dataArr[20]);
			        int OPS_Plus = Integer.parseInt(dataArr[21]);
			        int TB = Integer.parseInt(dataArr[22]);
			        int GDP = Integer.parseInt(dataArr[23]);
			        int HBP = Integer.parseInt(dataArr[24]);
			        int SH = Integer.parseInt(dataArr[25]);
			        int SF = Integer.parseInt(dataArr[26]);
			        int IBB = Integer.parseInt(dataArr[27]);
			        String posSummary = dataArr[28];
			        String nameAdditional = dataArr[29];
			        Batter newBatter = new Batter(rank,name,age,team,G,PA,AB,R,H,B2,B3,HR,RBI,SB,CS,BB,SO,BA,OBP,SLG,OPS,OPS_Plus,TB,GDP,HBP,SH,SF,IBB,posSummary,nameAdditional);
			        String[] namearr = name.split(" ");
			       //remove * from name if it has one
			        if(namearr[1].contains("*")) {
			        	namearr[1].replace("*","");
			        }
			        //make hash key last name,first inital
			        String hashkey = namearr[1] + "," + namearr[0].charAt(0);
			        //add batter to hashmap
			        batters.put(hashkey,newBatter);
			        batterkeys.add(hashkey);
			      }

			 top50 = 0;
			 while(s.hasNextLine()) {
			        String data = s.nextLine();
			        String[] dataArr = data.split(",", -1);
			        

			        //checks for empty strings in the array
			        //was encountering issues with double values being blank in the csv file, this just fills them in with 0s to avoid a 
			        //NumberFormatException
			        for(int i = 0; i < dataArr.length; i++) {
			        	if(dataArr[i].isEmpty()) {
			        		dataArr[i] = "0";
			        	}
			        }
			        //we only need the top 50 for our first sprint
			        //this will only grab the top 50 players
			        top50++;
			        
			        
			        int rank = Integer.parseInt(dataArr[0]);
			        String name = dataArr[1];
			        int age = Integer.parseInt(dataArr[2]);
			        String team = dataArr[3];
			        int wins = Integer.parseInt(dataArr[4]);
			        int losses = Integer.parseInt(dataArr[5]);
			        double wlper = Double.parseDouble(dataArr[6]);
			        double era = Double.parseDouble(dataArr[7]);
			        int g = Integer.parseInt(dataArr[8]);
			        int gs = Integer.parseInt(dataArr[9]);
			        int gf = Integer.parseInt(dataArr[10]);
			        int cg = Integer.parseInt(dataArr[11]);
			        int sho = Integer.parseInt(dataArr[12]);
			        int sv = Integer.parseInt(dataArr[13]);
			        Double ip = Double.parseDouble(dataArr[14]);
			        double h = Double.parseDouble(dataArr[15]);
			        int r = Integer.parseInt(dataArr[16]);
			        int er = Integer.parseInt(dataArr[17]);
			        int hr = Integer.parseInt(dataArr[18]);
			        int bb = Integer.parseInt(dataArr[19]);
			        int ibb = Integer.parseInt(dataArr[20]);
			        int so = Integer.parseInt(dataArr[21]);
			        int hbp = Integer.parseInt(dataArr[22]);
			        int bk = Integer.parseInt(dataArr[23]);
			        int wp = Integer.parseInt(dataArr[24]);
			        int bf = Integer.parseInt(dataArr[25]);
			        int eraPlus = Integer.parseInt(dataArr[26]);
			        double fip = Double.parseDouble(dataArr[27]);
			        double whip = Double.parseDouble(dataArr[28]);
			        double h9 = Double.parseDouble( dataArr[29]);
			        double hr9 = Double.parseDouble(dataArr[30]);
			        double bb9 = Double.parseDouble(dataArr[31]);
			        double so9 = Double.parseDouble(dataArr[32]);
			        double sow = Double.parseDouble(dataArr[33]);
			        String ad_name = dataArr[34];
			        String[] namearr = name.split(" ");
			       //remove * from name if it has one
			        if(namearr[1].contains("*")) {
			        	namearr[1].replace("*","");
			        }
			        Pitcher newPitcher = new Pitcher(rank,name,age,team,wins,losses,wlper,era,g,gs,gf,cg,sho,sv,ip,h,r,er,hr,bb,ibb,so,hbp,bk,wp,bf,eraPlus,fip,whip,h9,hr9,bb9,so9,sow,ad_name);
			        //make hash key last name,first inital
			        String hashkey = namearr[1] + "," + namearr[0].charAt(0);
			        //add batter to hashmap
			        pitchers.put(hashkey,newPitcher);
			        pitcherkeys.add(hashkey);
			 }
			 	
			 
			      s.close();
			      batscan.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
		
	}
	public 
	void overall(String pos) {
		// Convert pos string to enum position
		Batter.Position position = Batter.posStringToEnum(pos);
		// "Header"
		System.out.println();
		System.out.println("OVERALL");
		System.out.println();
		System.out.println("Name | Real Team | Position | Valuation " + '(' + batterExp + ')');
		System.out.println("========================================");

		// Temporary list for sorting
		ArrayList<Batter> batterArrList = new ArrayList<>();

		// Add all batters from hashmap into arrList
		for(String key : batterkeys){
			Batter batter = batters.get(key);
			// If the batter matches the position and is not drafted, add them to the array list
			if(batter.position == position && !batter.drafted){
				batterArrList.add(batter);
			}
		}
			
		// Sort all batters in the array list by ranking
		Collections.sort(batterArrList, new BatterComparitorByValuation());
		Collections.reverse(batterArrList);

		// Navigate through the hash map, print out any players that match the position
		for(Batter batter : batterArrList){
				System.out.println(batter.name + " | " + batter.team + " | " + batter.position + " | " + batter.BA);
			}
		}
	void overall(){
		// "Header"
		System.out.println();
		System.out.println("OVERALL");
		System.out.println();
		System.out.println("Rank | Name | Real Team | Position | Valuation " + '(' + batterExp + ')');
		System.out.println("===============================================");

		// Temporary list for sorting
		ArrayList<Batter> batterArrList = new ArrayList<>();

		// Add all batters from hashmap into arrList
		for(String key : batterkeys){
			Batter batter = batters.get(key);
			// If the batter is not drafted, add them to array list
			if(!batter.drafted)
				batterArrList.add(batter);
			}
			
		// Sort all batters in the array list by ranking
		Collections.sort(batterArrList, new BatterComparitorByValuation());
		Collections.reverse(batterArrList);

		for(Batter batter : batterArrList){
			System.out.println(batter.rank + " | " + batter.name + " | " + batter.team + " | " + batter.position + " | " + batter.BA);
		}
	}
	void poverall() {
		// HEADER
		System.out.println();
		System.out.println("POVERALL");
		System.out.println();
		System.out.println("Rank | Name | Real Team | Valuation " + '(' + pitcherExp + ')');
		System.out.println("===================================");

		// Temporary list
		ArrayList<Pitcher> pitcherArrList = new ArrayList<>();

		// Add all pitchers from hashmap into arrList
		for(String key : pitcherkeys){
			Pitcher pitcher = pitchers.get(key);
			if(!pitcher.drafted)
			// If the pitcher is not drafted, add them to array list
				pitcherArrList.add(pitcher);
			}

		Collections.sort(pitcherArrList, new PitcherComparitorByValuation());
		Collections.reverse(pitcherArrList);

		for(Pitcher pitcher : pitcherArrList){
			System.out.println(pitcher.rank + " | " + pitcher.name + " | " + pitcher.team + " | " + pitcher.ip);
		}
	}
	void team(String leagueMember) {
		LeagueMember member = findMember(leagueMember);
		member.team.printTeam(leagueMember); //probably wanna change this, but I've got other things to worry about rn	
	}
	void stars(String leagueMember) {
		LeagueMember member = findMember(leagueMember);
		member.team.printStars(leagueMember);
	}
	void evalfun(String expression) {
		Batter tester = new Batter();
		if(tester.validExpression(expression)){
			for(String key : batterkeys){
			Batter batter = batters.get(key);
			batter.setValuation(expression);
			}
			batterExp = expression.toUpperCase();
			System.out.println('"' + batterExp + '"' + " set as valuation.");
		}
		else{
			System.out.println('"' + expression.toUpperCase() + '"' + " is not a valid expression.");
			System.out.println();
			System.out.println("Valid variables: \"AVG\", \"OBP\", \"AB\", \"SLG\", \"SB\"");
			System.out.println("Valid operators: +, -, *, / (and more might be supported)");
		}
		
	}
	void pevalfun(String expression) {
		Pitcher tester = new Pitcher();
		if(tester.validExpression(expression)){
			for(String key : pitcherkeys){
			Pitcher pitcher = pitchers.get(key);
			pitcher.setValuation(expression);
			}
			pitcherExp = expression.toUpperCase();
			System.out.println('"' + pitcherExp + '"' + " set as valuation.");
		}
		else{
			System.out.println('"' + expression.toUpperCase() + '"' + " is not a valid expression.");
			System.out.println();
			System.out.println("Valid variables: \"IP\", \"G\", \"GS\", \"ERA\", \"BB\"");
			System.out.println("Valid operators: +, -, *, / (and more might be supported)");
		}
	}
	// void help() {
	// 	System.out.println("ran help");
	// }

	void odraft(String playerName, String leagueMember){
		//checks to see if the player name is contained within quotation marks using a regular expression
		//pattern should be a string that begins with quotation marks, contains one capital letter, one or more lowercase letters, then ends with quotation marks
		//defines pattern to look for
		Pattern pattern = Pattern.compile("^\"[A-Z][a-z]+,?[A-Z]*\"$"); 
		//checks player name for pattern
		Matcher matcher = pattern.matcher(playerName);
		if(!matcher.find()) {
			System.out.println("Syntax error in odraft, put player name in quotation marks and try again");
			return;
		}
		//finds the desired league member
		LeagueMember member = findMember(leagueMember);
		//if the League member was incorrect (they entered a leage member that does not exist)
		if(member == null) {
			//print error message
			System.out.println("The League member you entered was incorrect, no player has been drafted");
			//go back
			return;
		}
		//removes the quotation marks from the player name to search the hash tables
		//you never said we had to incorperate the double quotes into the tables, just that they were required when taking an input
		playerName = playerName.replace("\"", "");

		//used to count the number of players that come up with similar names
		int counter = 0;
		//used to retrive batter/pitcher from db
		Batter batterToDraft = null;
		Pitcher pitcherToDraft = null;
		//search through the batters first
		//create an itterator, go through the list of keys to see if there is a key that contains the existing string
		for(Iterator<String> bit = batterkeys.iterator(); bit.hasNext();) {
			String current = bit.next();
			//if the current key contains the name entered
			if(current.contains(playerName)) {
				//save it
				batterToDraft = batters.get(current);
				//increment counter
				counter++;
			}
		}
		//if a player was found in the batter db
		if(batterToDraft != null) {
			//if more than one person came up while searching
			if(counter > 1) {
				System.out.println("The name you entered was not specific enough, no player has been drafted");
				return;
			}
			else {
				member.addTeamMember(batterToDraft);
			}
		}
		//otherwise, nobody with that name was found in the batter db
		else {
			for(Iterator<String> pit = pitcherkeys.iterator(); pit.hasNext();) {
				String current = pit.next();
				//if the current key contains the name entered
				if(current.contains(playerName)) {
					//save it
					pitcherToDraft = pitchers.get(current);
					//increment counter
					counter++;
				}
			}
			if(counter > 1) {
				System.out.println("The name you entered was not specific enough, no player has been drafted");
				return;
			}
			//if nobody came up while searching
			else if(counter < 1) {
				System.out.println("Unable to find an undrafted player by that name, try again with a different name");
			}
			else {
				member.addTeamMember(pitcherToDraft);
			}

		}
	}
	void idraft(String playerName) {
		//idraft is nothing more than a shortcut to draft for person a
		odraft(playerName,"a");
	}
	
	private LeagueMember findMember(String leagueMember) {
		LeagueMember member = null;
		switch(leagueMember.toLowerCase()) {
		case "a":
			member = this.a;
			break;
		case "b":
			member = this.b;
			break;
		case "c":
			member = this.c;
			break;
		case "d":
			member = this.d;
			break;
		default:
			member = null;
		}
		return member;
	}
	
	public void undraft(String playerName, String leagueMember) {
		//checks to see if the player name is contained within quotation marks using a regular expression
				//pattern should be a string that begins with quotation marks, contains one capital letter, one or more lowercase letters, then ends with quotation marks
				//defines pattern to look for
				Pattern pattern = Pattern.compile("^\"[A-Z][a-z]+,?[A-Z]*\"$"); 
				//checks player name for pattern
				Matcher matcher = pattern.matcher(playerName);
				if(!matcher.find()) {
					System.out.println("Syntax error in undraft, put player name in quotation marks and try again");
					return;
				}
				//finds the desired league member
				LeagueMember member = findMember(leagueMember);
				//if the League member was incorrect (they entered a leage member that does not exist)
				if(member == null) {
					//print error message
					System.out.println("The League member you entered was incorrect, no player has been drafted");
					//go back
					return;
				}
				//removes the quotation marks from the player name to search the hash tables
				//you never said we had to incorperate the double quotes into the tables, just that they were required when taking an input
				playerName = playerName.replace("\"", "");
				//bater/pitcher to remove var
				Batter batterToRemove = null;
				Pitcher pitcherToRemove = null;
				//used to keep track of if entered player is on the given league members team
				boolean onTeam = false;
				//go through the names of all members on the league members team
				for(String star : member.team.stars){
					//split player name and make it match the format of the input player name
					String[] strspl = star.split(" ");
					String name = strspl[1] + "," + strspl[0].charAt(0);
					//if the current player name matches name of player on the team 
					if(name.equals(playerName)) {
						//player is on the team
						onTeam = true;
						//search through batter table keys to find the batter
						for(String b : batters.keySet()) {
							//if the batter is found
							if(b.equals(playerName)) {
								batterToRemove = batters.get(b);
								member.removeTeamMember(batterToRemove);
								System.out.println(star + " has been undrafted");
								break;
							}
							//otherwise, the player is on the team, but is not a batter
							else {
								//look through the pitcher table
								for(String p : pitchers.keySet()) {
									//if the pitcher is found
									if(p.equals(playerName)) {
										pitcherToRemove = pitchers.get(p);
										member.removeTeamMember(pitcherToRemove);
										System.out.println(star + " has been undrafted");
										break;
									}
		
							}
							}
							
						}
					}
					//if the given player was not found on the team
					if(!onTeam) {
						System.out.println("Could not find a player on the given members team with that name, try again");
					}
				}
	}
}
