
import java.io.Serializable;
import java.io.FileNotFoundException;
import org.junit.*;
// import org.junit.jupiter.api.Assertions.*;

// import org.junit.jupiter.api.Test;

public class JUnitDebugging implements Serializable{
	FantasyMatch match1 = new FantasyMatch();
	// FantasyMatch match1;
	// FantasyUI ui1;
	// RunFantasyBaseball fantasyBaseball1;
	
	@Test
	public void testFantasyDraft() {
		match1.odraft(null, null);
		match1.idraft(null);
	}
	@Test
	public void testFantasyMatch() {
		match1.overall("CF");
		match1.overall();
		match1.poverall();
		// match1.poverall();
		// match1.team(null);
		// match1.stars(null);
		// match1.evalfun(null);
		// match1.pevalfun(null);
		// match1.help();
	}
	// @Test
	// public void testFantasyUI() {
	// 	assertEquals(ui1.getInput("Input"),"Input");
	// 	ui1.display();
	// }
	// @Test
	// public void testRunFantasyBaseball() {
	// 	fantasyBaseball1.save();
	// 	fantasyBaseball1.restore();	
	// 	fantasyBaseball1.delete();
	// }
	@Test
	public void testUI() throws FileNotFoundException{
		FantasyUI.help();
	}

	@Test
	public void eval() {
		Batter batter = new Batter();
		batter.BA = 2;
		batter.OBP = 1;
		System.out.println(batter.evaluate("TEST"));
	}
}
