
import java.io.*;
import java.util.*;


public class RunFantasyBaseball implements Serializable{
	static FantasyMatch match = new FantasyMatch();
	static FantasyUI ui = new FantasyUI();
public static void main(String[] args) throws FileNotFoundException {

boolean loop = true;

ui.displayTitle();
ui.display();
System.out.println();
while (loop) {
	String command[];
	command = ui.getInput();
	playDraft(command);
}
	
	}
	public static void playDraft(String[] command) {
		String[] playerName;
		switch (command[0]) {
		case "ODRAFT":
			//if the user did not enter a league member to draft the player to
			if(command.length < 3) {
				System.out.println("No league member was entered, no player has been drafted");
				break;
			}
			match.odraft(command[1], command[2]);
			break;
		case "IDRAFT":
			if (command.length < 2){
				System.out.println("Improper usage");
				break;
			}
			match.idraft(command[1]);
			break;
		case "TEAM":
			if (command.length < 2){
				System.out.println("Improper usage");
				break;
			}
			match.team(command[1]);
			break;
		case "OVERALL":

			// Will perform default overall command if there is no additional argument given
			if (command.length == 1){
				match.overall();
				break;
			}
			match.overall(command[1]);
			break;
		case "POVERALL":
			match.poverall();
			break;
		case "EVALFUN":
			if (command.length == 1){
				System.out.println("Invalid usage.");
				break;
			}
			match.evalfun(command[1]);
			break;
		case "PEVALFUN":
			if (command.length == 1){
				System.out.println("Invalid usage.");
				break;
			}
			match.pevalfun(command[1]);
			break;
		case "STARS":
			if (command.length < 2){
				System.out.println("Improper usage");
				break;
			}
			match.stars(command[1]);
			break;
		case "SAVE":
			System.out.print("What would you like to name the file you want to save to? (Type for N in N.txt): ");
			Scanner s = new Scanner(System.in);
			String fileName = s.next();
			save(fileName);
			break;
		case "RESTORE":
			System.out.print("What is the name of the file that your system state was saved to? (Type for N in N.txt): ");
			Scanner k = new Scanner(System.in);
			String savedState = k.next();
			restore(savedState);
			break;
			
		case "HELP":
			ui.help();
			break;
		case "OUNDRAFT":
			//if the user didnt enter the command correctly
			if(command.length < 3) {
				System.out.println("Improper usage");
				break;
			}
			match.undraft(command[1], command[2]);
			break;
		case "IUNDRAFT":
			//if the user didnt enter the command correctly
			if(command.length < 2) {
				System.out.println("Improper usage");
				break;
			}
			match.undraft(command[1], "a");
			break;
			
		case "QUIT":
			System.out.println("Thank you for using Fantasy Baseball drafting tool");
			System.exit(0);
		case "EXIT":
			System.out.println("Thank you for using Fantasy Baseball drafting tool");
			System.exit(0);
		default:
			System.out.println("Invalid command, try again");
		}
	}
	public static void save(String fileName) {
    	fileName += ".txt";
    	try {
    		//creates an ObjectOutputStream to write the current to a file
    		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File(fileName)));
			//prints to file
			oos.writeObject(match);
			System.out.println("The state of the system has been saved in " + fileName + "!");
			//closes ObjectOutputStream
			oos.close();
		} catch (IOException e) {
			//System.out.println( "Unable to save the state of the system to a file named " + fileName);
			e.printStackTrace();
		}

    }
	public static void restore(String fileName) {
    	//String for taking an input file name
    	//prompts user for input file name
    	fileName += ".txt";
    	try {
    		//creates ObjectInputStream using given file name
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File(fileName)));
			//sets collection equal to the retrieved object
			match = (FantasyMatch) ois.readObject();
			//closes ObjectInputStream
			ois.close();
			System.out.println("The state of the system has been restored from " + fileName + "!");
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("Unable to restore the state of the system from a file named "+ fileName);
		}
	}
	void delete(){
		System.out.println("ran delete");
	}

}
