
import java.io.Serializable;
import java.util.ArrayList;

public class Team implements Serializable{
	//players for each position
	Batter catcher;
	Batter firstBase;
	Batter secondBase;
	Batter thirdBase;
	Batter shortStop;
	Batter rightField;
	Batter centerField;
	Batter leftField;
	Pitcher[] pitchers;
	Batter emptyBatter;
	Pitcher emptyPitcher;
	int pitchercount;
	
	// ArrayList for stars command
	public ArrayList<String> stars = new ArrayList<>();
	//initalize everything to null, everything is set by set methods(this is to check if the spot is filled)
	public Team() {
		catcher = null;
		firstBase = null;
		secondBase = null;
		thirdBase = null;
		shortStop = null;
		rightField = null;
		centerField = null;
		leftField = null;
		//a team must have 5 pitchers
		pitchers = new Pitcher[5];
	}
	
	//method to set catcher
	public void setCatcher(Batter player) {
		//if the current team already has a catcher
		if(this.catcher != null) {
			//print the error message instead of drafting
			System.out.println("Team already has a catcher, no player was drafted");
		}
		//otherwise
		else {
			//the given catcher is added to the team
			this.catcher = player;
			//batter has been drafted, set drafed to true
			catcher.drafted = true;
			System.out.println(player.name +" Has been drafted");
			stars.add(player.name);
		}
	}
	//method to set first base player, works the same as setCatcher
	public void setFirstBase(Batter player) {
		if(this.firstBase != null) {
			System.out.println("Team already has a first base, no player was drafted");
		}
		else {
			this.firstBase = player;
			firstBase.drafted = true;
			System.out.println(player.name +" Has been drafted");
			stars.add(player.name);
		}
	}
	//method to set second base player, works the same as setCatcher
	public void setSecondBase(Batter player) {
		if(this.secondBase != null) {
			System.out.println("Team already has a second base, no player was drafted");
		}
		else {
			this.secondBase = player;
			player.drafted = true;
			System.out.println(player.name +" Has been drafted");
			stars.add(player.name);
		}
	}
	//method to set third base player, works the same as setCatcher
	public void setThirdBase(Batter player) {
		if(this.thirdBase != null) {
			System.out.println("Team already has a third base, no player was drafted");
		}
		else {
			this.thirdBase = player;
			player.drafted = true;
			System.out.println(player.name +" Has been drafted");
			stars.add(player.name);
		}
	}
	//method to set short stop player, works the same as setCatcher
	public void setShortStop(Batter player) {
		if(this.shortStop != null) {
			System.out.println("Team already has a short stop, no player was drafted");
		}
		else {
			this.shortStop = player;
			player.drafted = true;
			System.out.println(player.name +" Has been drafted");
			stars.add(player.name);
		}
	}
	//method to set right field player, works the same as setCatcher
	public void setRightField(Batter player) {
		if(this.rightField != null) {
			System.out.println("Team already has a catcher, no player was drafted");
		}
		else {
			this.rightField = player;
			player.drafted = true;
			System.out.println(player.name +" Has been drafted");
			stars.add(player.name);
		}
		
	}
	//method to set center field player, works the same as setCatcher
	public void setCenterField(Batter player) {
		if(this.centerField != null) {
			System.out.println("Team already has a catcher, no player was drafted");
		}
		else {
			this.centerField = player;
			player.drafted = true;
			System.out.println(player.name +" Has been drafted");
			stars.add(player.name);
		}
	}
	//method to set left field player, works the same as setCatcher
	public void setLeftField(Batter player) {
		if(this.secondBase != null) {
			System.out.println("Team already has a catcher, no player was drafted");
		}
		else {
			this.secondBase = player;
			player.drafted = true;
			System.out.println(player.name +" Has been drafted");
			stars.add(player.name);
		}
	}
	//method to add a pitcher
	public void addPitcher(Pitcher pitcher) {
		//if the team already has 5 pitchers
		if(pitchercount >= 5) {
			//print an error message
			System.out.println("Team already has 5 pitchers, no player was drafted");
		}
		//otherwise
		else {
			//start at the first pitcher
			int i = 0;
			//go cycle through until an empty pitcher is found
			while(pitchers[i] != null) {
				i++;
			}
			//new pitcher is added
			pitchers[i] = pitcher;
			//pitcher has been drafted, set drafted to true
			pitcher.drafted = true;
			pitchercount++;
			System.out.println(pitcher.name +" Has been drafted");
			stars.add(pitcher.name);
		}
	}
	public void removePitcher(Pitcher remove) {
		int i = 0;
		while(pitchers[i] != remove) {
			i++;
		}
		pitchers[i] = null;
		pitchers[i].drafted = false;
		pitchercount--;
		//removes gaps left by deleted pitchers
		for(i = 0; i < 5; i++) {
			if(pitchers[i] == null && i + 1 < 5) {
				pitchers[i] = pitchers[i+1];
				pitchers[i+1] = null;
			}
		}
		
	}
	public void printTeam(String name) {
		System.out.println(name + "'s Team\n====================================");
		System.out.println("Catcher: ");
		checkPlayer(catcher);
		System.out.println("First Base: ");
		checkPlayer(firstBase);
		System.out.println("Second Base: ");
		checkPlayer(secondBase);
		System.out.println("Third Base:");
		checkPlayer(thirdBase);
		System.out.println("Short Stop:");
		checkPlayer(shortStop);
		System.out.println("Left Field:");
		checkPlayer(leftField);
		System.out.println("Center Field: ");
		checkPlayer(centerField);
		System.out.println("Right Field: ");
		checkPlayer(rightField);
		for(int i = 0; i < pitchers.length; i++) {
			System.out.println("Pitcher "+ (i+1) + ": ");
			checkPlayer(pitchers[i]);
		}

	}


	
	/**
	 * Prints the players out in the order they were added
	 * @param name - draft player
	 */
	public void printStars(String name){
		System.out.println(name + "'s Stars\n====================================");

		// Prints the players out one per line
		for(String star : stars){
			System.out.println(star);
		}

		System.out.println();
	}

	public static void checkPlayer(Batter b) {
		if(b == null) {
			System.out.print(" none\n");
		}
		else {
			System.out.print(" " + b.name + "\n");
		}
	}
	public static void checkPlayer(Pitcher b) {
		if(b == null) {
			System.out.print(" none\n");
		}
		else {
			System.out.print(" " + b.name + "\n");
		}
	}
}
