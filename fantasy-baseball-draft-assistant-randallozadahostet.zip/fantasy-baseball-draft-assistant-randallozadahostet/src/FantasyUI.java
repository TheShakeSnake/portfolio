
import java.util.*;
import java.io.*;
public class FantasyUI implements Serializable{
	Scanner input = new Scanner(System.in);
	public String[] getInput(){
		String[] command;
		System.out.println("ENTER COMMAND");
		String userInput = input.nextLine();
		command = userInput.split(" ");
		command[0] = command[0].toUpperCase();
		return command;
	}
	public static void display() {
		System.out.println("==============================================");
		try{
			File file = new File("./.git/ORIG_HEAD");
			Scanner gitFile = new Scanner(file);
			String gitVersion = gitFile.next().substring(0,7);
			System.out.println("Git version: " + gitVersion);
			System.out.println();
			gitFile.close();
		}
		catch (Exception FileNotFoundException){}
		System.out.println("Welcome to Fantasy Baseball drafting tool,");
		System.out.println("run command HELP for more info.");
		System.out.println("==============================================");
		
	}

	public static void help() {
		System.out.println("Commands");
		System.out.println("================");
		System.out.println();
		System.out.println("ODRAFT - Drafts for users A, B, C, or D");
		System.out.println("Ex: ODRAFT " + '"' + "LastName,(First Initial)" + '"' + " B");
		System.out.println();
		System.out.println("IDRAFT - Drafts only user A");
		System.out.println("Ex: IDRAFT " + '"' + "LastName,(First Initial)" + '"');
		System.out.println();
		System.out.println("OUNDRAFT - Undrafts for users A, B, C, or D");
		System.out.println("Ex: OUNDRAFT " + '"' + "LastName,(First Initial)" + '"' + " B");
		System.out.println();
		System.out.println("IUNDRAFT - Undrafts only user A");
		System.out.println("Ex: IUNDRAFT " + '"' + "LastName,(First Initial)" + '"');
		System.out.println();
		System.out.println("TEAM - Displays the team of users A, B, C, or D and sorts by position");
		System.out.println();
		System.out.println("OVERALL - Displays all batters of all or one specific position");
		System.out.println("Ex: OVERALL or OVERALL CF");
		System.out.println("Available positions: C, 1B, 2B, 3B, SS, LF, CF, RF");
		System.out.println();
		System.out.println("POVERALL - Displays all pitchers");
		System.out.println();
		System.out.println("EVALFUN - Set evaluation method for batters");
		System.out.println("Example: EVALFUN AVG+OBP");
		System.out.println("Usage is not case sensitive.");
		System.out.println("Valid variables: \"AVG\", \"OBP\", \"AB\", \"SLG\", \"SB\"");
		System.out.println("Valid operators: +, -, *, / (and more might be supported)");
		System.out.println();
		System.out.println("PEVALFUN - Set evaluation method for pitchers");
		System.out.println("Example: PEVALFUN IP-G");
		System.out.println("Usage is not case sensitive.");
		System.out.println("Valid variables: \"IP\", \"G\", \"GS\", \"ERA\", \"BB\"");
		System.out.println("Valid operators: +, -, *, / (and more might be supported)");
		System.out.println();
		System.out.println("STARS - Displays the team of users A, B, C, or D and sorts by order added");
		System.out.println();
		System.out.println("SAVE - Save the system state to a txt file.");
		System.out.println();
		System.out.println("RESORE - Restore the system state from a txt file.");
		System.out.println();
		System.out.println("DELETE - WIP");
		System.out.println();
		System.out.println("HELP - Displays this message");
		System.out.println();
		System.out.println("QUIT - Exits this program");
		System.out.println();
	}

	public static void displayTitle(){
		// Display title
		System.out.println("______          _                 ______                _           _ _______            __ _   \n" + //
				"|  ___|        | |                | ___ \\              | |         | | |  _  \\          / _| |  \n" + //
				"| |_ __ _ _ __ | |_ __ _ ___ _   _| |_/ / __ _ ___  ___| |__   __ _| | | | | |_ __ __ _| |_| |_ \n" + //
				"|  _/ _` | '_ \\| __/ _` / __| | | | ___ \\/ _` / __|/ _ \\ '_ \\ / _` | | | | | | '__/ _` |  _| __|\n" + //
				"| || (_| | | | | || (_| \\__ \\ |_| | |_/ / (_| \\__ \\  __/ |_) | (_| | | | |/ /| | | (_| | | | |_ \n" + //
				"\\_| \\__,_|_| |_|\\__\\__,_|___/\\__, \\____/ \\__,_|___/\\___|_.__/ \\__,_|_|_|___/ |_|  \\__,_|_|  \\__|\n" + //
				"                              __/ |                                                             \n" + //
				"                             |___/                                                              \n" + //
				"\n" + //
				"");
	}
}
