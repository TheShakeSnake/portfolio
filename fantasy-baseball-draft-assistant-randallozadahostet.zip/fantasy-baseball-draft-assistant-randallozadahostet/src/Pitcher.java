
import java.io.Serializable;
import java.util.Comparator;

import net.objecthunter.exp4j.ExpressionBuilder;
import net.objecthunter.exp4j.tokenizer.UnknownFunctionOrVariableException;

public class Pitcher implements Comparable<Pitcher>, Serializable{
String name,team,ad_name;
int rank,wins,losses,age,g,gs,gf,cg,sho,sv,r,er,hr,bb,ibb,so,hbp,bk,wp,bf,eraplus;
double wlper,era,h,sow,so9,bb9,h9,fip,whip, ip, hr9;
boolean drafted;
float valuation;

public Pitcher(int rank,String name,int age, String team,int wins, int losses, double wlper, double era,int g,int gs,int gf,int cg,int sho, int sv,
		double ip, double h, int r, int er, int hr, int bb, int ibb, int so, int hbp, int bk, int wp, int bf, int eraplus, double fip, double whip,  double sow, double h9, double hr9, double bb9, double so9, String nameadd) { 
	
	this.rank = rank;
	this.name = name;
	this.age = age;
	this.team = team;
	this.wins = wins;
	this.losses = losses;
	this.wlper = wlper;
	this.era = era;
	this.g = g;
	this.gs = gs;
	this.gf = gf;
	this.cg = cg;
	this.sho = sho;
	this.sv = sv;
	this.ip = ip;
	this.r = r;
	this.er = er;
	this.hr = hr;
	this.bb = bb;
	this.ibb = ibb;
	this.so = so;
	this.hbp = hbp;
	this.bk = bk;
	this.wp = wp;
	this.bf = bf;
	this.eraplus = eraplus;
	this.h = h;
	this.sow = sow;
	this.bb9 = bb9;
	this.h9 = h9;
	this.fip = fip;
	this.whip = whip;
	ad_name = nameadd;
	this.hr9 = hr9;
	this.so9 = so9;
	drafted = false;
	this.valuation = (float) this.ip;
}
public Pitcher() {
	this.rank = 0;
	this.name = "";
	this.age = 0;
	this.team = "";
	this.wins = 0;
	this.losses = 0;
	this.wlper = 0;
	this.era = 0;
	this.g = 0;
	this.gs = 0;
	this.gf = 0;
	this.cg = 0;
	this.sho = 0;
	this.sv = 0;
	this.ip = 0;
	this.r = 0;
	this.er = 0;
	this.hr = 0;
	this.bb = 0;
	this.ibb = 0;
	this.so = 0;
	this.hbp = 0;
	this.bk = 0;
	this.wp = 0;
	this.bf = 0;
	this.eraplus = 0;
	this.h = 0;
	this.sow = 0;
	this.bb9 = 0;
	this.h9 = 0;
	this.fip = 0;
	this.whip = 0;
	this.hr9 = 0;
	this.so9 = 0;
	ad_name = "";
	drafted = false;
	this.valuation = (float) this.ip;
}
	@Override
    public int compareTo(Pitcher pitcher){
        float valuation1 = this.valuation;
        float valuation2 = pitcher.valuation;
        if(valuation1 > valuation2)
            return 1;
        else if(valuation1 < valuation2)
            return -1;
        else
            return 0;
    }

	public int compareRank(Pitcher pitcher){
        int rank1 = this.rank;
        int rank2 = pitcher.rank;
        if(rank1 > rank2)
            return 1;
        else if(rank1 < rank2)
            return -1;
        else
            return 0;
    }

	/**
     * Sets valuation to result of evaluate(operation)
     * @param operation
     */
    public void setValuation(String operation) {
        this.valuation = evaluate(operation);
    }

    public float evaluate(String operation) throws UnknownFunctionOrVariableException {
        double result = new ExpressionBuilder(operation.toUpperCase())
            .variables("IP", "G", "GS", "ERA", "BB")
            .build()
            .setVariable("G",this.g)
            .setVariable("GS",this.gs)
            .setVariable("ERA",this.era)
            .setVariable("IP",this.ip)
            .setVariable("BB",this.bb)
            .evaluate();
        
        return (float) result ;
    }

	public boolean validExpression(String operation){
		try{
			evaluate(operation);
		}
		catch(Exception UnknownFunctionOrVariableException){
			return false;
		}
		return true;
	}
}

class PitcherComparitorByRanking implements Comparator<Pitcher> {
    @Override
    public int compare(Pitcher p1, Pitcher p2){
        return p1.compareRank(p2);
    }
}

class PitcherComparitorByValuation implements Comparator<Pitcher> {
    @Override
    public int compare(Pitcher p1, Pitcher p2){
        return p1.compareTo(p2);
    }
}