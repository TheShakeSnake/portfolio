
import java.io.Serializable;
import java.util.Comparator;

import net.objecthunter.exp4j.ExpressionBuilder;
import net.objecthunter.exp4j.tokenizer.UnknownFunctionOrVariableException;


public class Batter implements Comparable<Batter>, Serializable{

    // Variables

    public int rank;
    public String name;
    public int age;
    public String team;
    public int G;
    public int PA;
    public int AB;
    public int R;
    public int H;
    public int B2;
    public int B3;
    public int HR;
    public int RBI;
    public int SB;
    public int CS;
    public int BB;
    public int SO;
    public double BA;
    public double OBP;
    public double SLG;
    public double OPS;
    public int OPS_Plus;
    public int TB;
    public int GDP;
    public int HBP;
    public int SH;
    public int SF;
    public int IBB;
    public String posSummary;
    public String nameAdditional;
    public Position position;
    public Boolean drafted;
    public float valuation;

    // Constructor

    public Batter(){
        this.rank = 0;
        this.name = "";
        this.age = 0;
        this.team = "";
        this.G = 0;
        this.PA = 0;
        this.AB = 0;
        this.R = 0;
        this.H = 0;
        this.B2 = 0;
        this.B3 = 0;
        this.HR = 0;
        this.RBI = 0;
        this.SB = 0;
        this.CS = 0;
        this.BB = 0;
        this.SO = 0;
        this.BA = 0;
        this.OBP = 0;
        this.SLG = 0;
        this.OPS = 0;
        this.OPS_Plus = 0;
        this.TB = 0;
        this.GDP = 0;
        this.HBP = 0;
        this.SH = 0;
        this.SF = 0;
        this.IBB = 0;
        this.posSummary = "";
        this.nameAdditional = "";
        this.position = null;
        this.drafted = false;
        this.valuation = (float) this.BA;
    }

    public Batter(int rank, String name, int age, String team, int g, int pa, int ab, int r, int h, int b2, int b3, int hr, int rbi, int sb, int cs, int bb, int so, double ba, double obp, double slg, double ops, int ops_Plus, int tb, int gdp, int hbp, int sh, int sf, int ibb, String posSummary, String nameAdditional) {
        this.rank = rank;
        this.name = name;
        this.age = age;
        this.team = team;
        this.G = g;
        this.PA = pa;
        this.AB = ab;
        this.R = r;
        this.H = h;
        this.B2 = b2;
        this.B3 = b3;
        this.HR = hr;
        this.RBI = rbi;
        this.SB = sb;
        this.CS = cs;
        this.BB = bb;
        this.SO = so;
        this.BA = ba;
        this.OBP = obp;
        this.SLG = slg;
        this.OPS = ops;
        this.OPS_Plus = ops_Plus;
        this.TB = tb;
        this.GDP = gdp;
        this.HBP = hbp;
        this.SH = sh;
        this.SF = sf;
        this.IBB = ibb;
        this.posSummary = posSummary;
        this.nameAdditional = nameAdditional;
        findPos(posSummary);
        this.drafted = false;
        this.valuation = (float) this.BA;
    }


    private void findPos(String posSummary) throws IllegalArgumentException{
    	char poschar = posSummary.charAt(0);
    	//check to see if the character grabbed is a digit or a *, if it isn't...
    	if(!Character.isDigit(poschar)) {
    		//grab the next character, which should be the position the character plays
    		poschar = posSummary.charAt(1);
    	}
    	String stringy = poschar + "";
    	int intchar = Integer.parseInt(stringy);
    	switch(intchar){
    	case 2:
    		position = Position.C;
    		break;
    	case 3:
    		position = Position.B1;
    		break;
    	case 4:
    		position = Position.B2;
    		break;
    	case 5:
    		position = Position.B3;
    		break;
    	case 6:
    		position = Position.SS;
    		break;
    	case 7:
    		position = Position.LF;
    		break;
    	case 8:
    		position = Position.CF;
    		break;
    	case 9:
    		position = Position.RF;
    		break;
        default:
            throw new IllegalArgumentException("IllegalArgumentException, position " + poschar + " not in range [2-9]");
    	}
    }

    public static Position posStringToEnum(String position){
        switch(position.toUpperCase()){
            case "C" :
                return Position.C;
            case "1B" :
                return Position.B1;
            case "2B" :
                return Position.B2;
            case "3B":
                return Position.B3;
            case "LF":
                return Position.LF;
            case "CF":
                return Position.CF;
            case "RF":
                return Position.RF;
            default:
                return null;
        }
    }

    public enum Position {
        C, // Catcher
        B1, // First Base
        B2, // Second Base
        B3, // Third Base
        SS, // Shortstop
        LF, // Left Field
        CF, // Center Field
        RF, // Right Field
    }

    @Override
    public int compareTo(Batter batter){
        float valuation1 = this.valuation;
        float valuation2 = batter.valuation;
        if(valuation1 > valuation2)
            return 1;
        else if(valuation1 < valuation2)
            return -1;
        else
            return 0;
    }

    public int compareRank(Batter batter){
        int rank1 = this.rank;
        int rank2 = batter.rank;
        if(rank1 > rank2)
            return 1;
        else if(rank1 < rank2)
            return -1;
        else
            return 0;
    }
    /**
     * Sets valuation to result of evaluate(operation)
     * @param operation
     */
    public void setValuation(String operation) {
        this.valuation = evaluate(operation);
    }

    public float evaluate(String operation) throws UnknownFunctionOrVariableException {
        double result = new ExpressionBuilder(operation.toUpperCase())
            .variables("AVG", "OBP", "AB", "SLG", "SB")
            .build()
            .setVariable("AVG",this.BA)
            .setVariable("OBP",this.OBP)
            .setVariable("AB",this.AB)
            .setVariable("SLG",this.SLG)
            .setVariable("SB",this.SB)
            .evaluate();
        
        return (float) result ;
    }

    public boolean validExpression(String operation){
		try{
			evaluate(operation);
		}
		catch(Exception UnknownFunctionOrVariableException){
			return false;
		}
		return true;
	}
}

class BatterComparitorByRanking implements Comparator<Batter> {
    @Override
    public int compare(Batter b1, Batter b2){
        return b1.compareRank(b2);
    }
}

class BatterComparitorByValuation implements Comparator<Batter> {
    @Override
    public int compare(Batter b1, Batter b2){
        return b1.compareTo(b2);
    }
}
