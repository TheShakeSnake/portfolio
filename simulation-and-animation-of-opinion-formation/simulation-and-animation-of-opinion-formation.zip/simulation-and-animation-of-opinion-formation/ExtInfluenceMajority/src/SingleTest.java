
public class SingleTest {
	public static void main(String[] args) {
		double density = 0.5;
		int seed =  (int)(Math.random()*(90000-10000+1)+10000); 
		double influence = 0.17;
		Majority m = new Majority(100, 1000,density, seed, 0.0, influence);	
		m.run();

	}
}
