
//Program tests group rule opinion dynamics
public class GroupTester
{
 public static void main(String[] args)
 {
      //create majority object
      Group m = new Group(100, 1000, 0.5, 46235, 0.01, .5);

      //run simulation
      m.run();
 }  
}  