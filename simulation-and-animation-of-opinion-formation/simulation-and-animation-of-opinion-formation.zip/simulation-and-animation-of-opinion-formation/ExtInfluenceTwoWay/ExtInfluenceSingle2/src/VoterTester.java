
//Program tests imitation opinion dynamics
public class VoterTester
{
   public static void main(String[] args)
   {
	   double noise = 0.1;
	   int seed = 21576;
        //create a voter object
        Voter v = new Voter(100, 1000, 0.9, seed, noise, .5);

        //run simulation
        v.run();
   }  
}  
