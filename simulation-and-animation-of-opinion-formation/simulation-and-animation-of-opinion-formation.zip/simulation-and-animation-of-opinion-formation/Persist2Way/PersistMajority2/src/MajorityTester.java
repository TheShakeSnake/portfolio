
//Program tests majority rule opinion dynamics
public class MajorityTester
{
   public static void main(String[] args)
   {
        //create majority object
        Majority m = new Majority(100, 1000, 0.5, 46235, 0.2, 0.2, 0.1);

        //run simulation
        m.run();
   }  
}  
