
//Program tests majority rule opinion dynamics
public class MajorityTester
{
   public static void main(String[] args)
   {
	     int tests = 10, size = 100;
	     double sdensity = 0.0, noise = 0.0, persistance = 0.75;
		 	Majority[] m = new Majority[10];																		//create array of Majority objects
		 	
		 	
		 	for(int j = 0; j <=10; j++) {																			//cycle through 11 times(0-1.0)
		 		double edensity = 0.0, avgdensity = 0.0;															//used for measuring ending density of one simulation and the average at the end
		 		int seed =  (int)(Math.random()*(90000-10000+1)+10000); 											//generates random seed within range, displayed at end with densities
		 		
		 		for(int i = 0; i<tests; i++) {
		 			m[i] = new Majority(size, 1000,sdensity, seed, persistance,noise);								//initialize Majority objects with given values
		 			m[i].run();
		 			edensity = m[i].getPlus()/(double)(size*size);													//takes number of people with plus opinion and divides by number of total people to get plus density
		 			avgdensity += edensity;																			//adds to average density
	   	  
	   	  seed += 150;																								//changes seed
	     }
		 			
	     avgdensity /= (double)tests;																				//finds average density
	     System.out.println("Seed: " + seed + " Start density: " + sdensity + " Avg end density: " +avgdensity);	//displays seed, starting density, and average density after given number of tests
	     		sdensity += 0.1;																					//increases starting density by 0.1 before starting the next set of tests
		 	}	
   }  
}  
