package project1;

//import project2.Voter;

//Program tests imitation opinion dynamics
public class VoterTester
{
   public static void main(String[] args)
   {
	      int tests = 10, size = 100;
	      double sdensity = 0.0, noise = 0.02;
		 	Voter[] m = new Voter[10];
		 	
		 	
		 	for(int j = 0; j <=10; j++) {
		 		double edensity = 0.0, avgdensity = 0.0;
		 		int seed =  (int)(Math.random()*(90000-10000+1)+10000); 
		 		
		 		for(int i = 0; i<tests; i++) {
		 			m[i] = new Voter(size, 1000,sdensity, seed, noise);
		 			m[i].run();
		 			edensity = m[i].getPlus()/(double)(size*size);
		 			avgdensity += edensity;
	    	  
	    	  seed += 150;
	      }
		 		
	      avgdensity /= (double)tests;
	      System.out.println("Seed: " + seed + " Start density: " + sdensity + " Avg end density: " +avgdensity);
	      		sdensity += 0.1;
		 	}
   }  
}  
