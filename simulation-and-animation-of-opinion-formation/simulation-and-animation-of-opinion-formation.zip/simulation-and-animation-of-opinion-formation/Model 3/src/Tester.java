
public class Tester {

	public static void main(String[] args) {
		
		int seed = 15868, size = 100;
		double startdensity = 0.0, enddensity = 0.0, avgdensity = 0.0;
		OtherMajority[] om = new OtherMajority[10];
		
		
		for(int i = 0; i < 10; i++) {
			double opina = 0.0;
			om[i] = new OtherMajority(100,1000,startdensity,seed);
			om[i].run();
			opina = om[i].getOpinA();
			enddensity = opina/(double)(size*size);
			
		
			avgdensity+=enddensity;
			seed+=1250;
		}
		avgdensity/=10.0;
		System.out.println(avgdensity);
		
		
		
		

	}

}
