import java.util.Random;
public class OtherMajority {
	private final int OpinA = 1;
	private final int OpinB = 2;
	
	private int[][] model;
    private int size;                 //size of array
    private int iterations;           //number of iterations
    private double density;           //initial density of plus opinion
    private Random random;            //random number generator
    private DrawOpinion drawer;       //drawing object
    
    public OtherMajority(int size, int iterations, double density, int seed){
    	this.model = new int[size][size];
    	this.size =  size;
    	this.iterations  = iterations;
    	this.density = density;
    	this.random = new Random(seed);
    	this.drawer = new DrawOpinion(model,size);
    }
    
    private void initalize() {
    	for(int i =  0;  i <  size;  i++) {
    		for(int j  = 0; j<size;j++) {
    			if(random.nextDouble() < density) {
    				model[i][j] = OpinA;
    			}
    			else
    				model[i][j] = OpinB;
    		}
    	}
    }
    
    private void convert(int i, int j) {
    	int opina = 0;						//initial  count  of people in  the group that hold opinion a
    	int opinb = 0;						//initial count  of  people in the group that  hold opinion b
    	int gopin = 0;						//used for holding the greater opinion
    	
    	if(model[i][j]  == OpinA) {			//finds opinion of currently selected person
    		opina++;
    	}
    	else
    		opinb++;
    	if(model[(i+1)%size][j]  == OpinA) {	//finds opinion of person  to  the south
    		opina++;
    	}
    	else
    		opinb++;
    	if(model[(i-1+size)%size][j]  == OpinA) {	//finds opinion of north  neighbor 
    		opina++;
    	}
    	else
    		opinb++;
    	if(model[i][(j+1)%size]  == OpinA) {	//finds opinion  of east  neighbor
    		opina++;
    	}
    	else
    		opinb++;
    	if(model[i][(j-1+size)%size]  == OpinA) {	//finds opinion  of west neighbor
    		opina++;
    	}
    	else
    		opinb++;
    	if(opina  < opinb) {					//finds the majority opinion of the  group
    		gopin  = OpinB;
    	}
    	else if(opina > opinb) {
    		gopin = OpinA;
    	}
    	else
    		if(random.nextDouble() < 0.5) {	//if there  is a tie, one opinion  is  picked at random
    			gopin= OpinA;
    		}
    		else
    			gopin  = OpinB;
    	model[i][j] = gopin;				//converts all members of the  group  to  whatever the greater opinion is
    	model[(i+1)%size][j] = gopin;
    	model[(i-1+size)%size][j] = gopin;
    	model[i][(j+1)%size] = gopin;
    	model[i][(j-1+size)%size] = gopin;
    }
    
    //Method draws array of opinions
    private void draw()
    {
        drawer.repaint();    //repaint array

        pause(1);         //pause for some time
    }
    
    //Method pauses program for some milliseconds
    private void pause(int milliseconds)
    {
        try 
        {
            Thread.sleep(milliseconds);
        }
        catch(InterruptedException e)
        {
            System.exit(0);
        }
    }
    
    public void  run() {
    	initalize();			//fills array  randomly with opinions  based on  density provided
    	
    	for(int x  = 0; x < iterations; x++) {
    		draw();
    		 for (int m = 0; m < size*size; m++) {
    		int i = random.nextInt(size);
    		int j = random.nextInt(size);
    		convert(i,j);
    		 }
    	}
    }
    
    /****************************************************************************************/
    public double getOpinA() {
   	 double opina = 0.0;
    	for(int i=0;i<size;i++) {
		 for(int j=0;j<size;j++) {
			 if(model[i][j] == OpinA)
				 opina++;
    }
    	}
    	return opina;
    }
    
}
