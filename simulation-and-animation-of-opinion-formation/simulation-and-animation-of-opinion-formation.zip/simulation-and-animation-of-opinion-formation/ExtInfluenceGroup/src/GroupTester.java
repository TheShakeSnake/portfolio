
//Program tests group rule opinion dynamics
public class GroupTester
{
 public static void main(String[] args)
 {
      int seed = 85364, tests = 10, size = 100;													
      double sdensity = 0.0, noise = 0.02, influence = 0.05;									
	 	Group[] m = new Group[10];																//create array of voter objects															
	 	for(int j = 0; j <=10; j++) {															//cycle through 11 times(0-1.0)
	 		double edensity = 0.0, avgdensity = 0.0;											//used for measuring ending density of one simulation and the average at the end
	 		for(int i = 0; i<tests; i++) {
	 			m[i] = new Group(size, 1000,sdensity, seed, noise, influence);					//initialize voter objects with given values
	 			m[i].run();
	 			edensity = m[i].getPlus()/(double)(size*size);									//takes number of people with plus opinion and divides by number of total people to get plus density
	 			avgdensity += edensity;															//adds to average density
    	  
    	  seed += 150;																			//changes seed
      }
      avgdensity /= (double)tests;																//finds average density
      System.out.println("Start density: " + sdensity + " Avg end density: " +avgdensity);		//displays seed, starting density, and average density after given number of tests
      		sdensity += 0.1;																	//increases starting density by 0.1 before starting the next set of tests
	 	}
      

 }  
}  