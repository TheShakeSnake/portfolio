
public class yea {

}
