package com.example.weatherapp;
import android.graphics.Typeface;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Calendar;
import java.util.Locale;
import java.util.Scanner;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class CityModel extends AppCompatActivity {
    private String url;
    private String cityName;
    private int zipCode;
    char currentWeatherIcon;
    String currentCondition;
    private double currentTemp;
    private double highTemp;
    private double lowTemp;
    private String day1;
    private String day2;
    private String day3;
    private char day1Icon;
    private char day2Icon;
    private char day3Icon;
    private int bgColor;

    private boolean ready;

    public void setReady(boolean ready) {
        this.ready = ready;
    }

    public boolean isReady() {
        return ready;
    }

    public String getCurrentCondition() {
        return currentCondition;
    }

    public String getCityName() {
        return cityName;
    }
    public char getCurrentWeatherIcon() {
        return currentWeatherIcon;
    }

    public double getCurrentTemp() {
        return currentTemp;
    }

    public double getHighTemp() {
        return highTemp;
    }

    public double getLowTemp() {
        return lowTemp;
    }

    public String getDay1() {
        return day1;
    }

    public String getDay2() {
        return day2;
    }

    public String getDay3() {
        return day3;
    }

    public char getDay1Icon() {
        return day1Icon;
    }

    public char getDay2Icon() {
        return day2Icon;
    }

    public char getDay3Icon() {
        return day3Icon;
    }

    public CityModel(int zipCode){
        this.zipCode = zipCode;
        this.url = "https://api.openweathermap.org/data/2.5/forecast?zip=" + zipCode + ",us&appid=e19ece920b9ab597096cd1e9c0b3ea99&units=imperial";
        httpInThread(url);
    }
    private void httpInThread(String url){
        new Thread(new Runnable() {
            String result = "HTTPS unable to get";
            @Override
            public void run() {
                // do your stuff
                result = downloadUrl(url);
                runOnUiThread(new Runnable() {
                    public void run() {
                        // do onPostExecute stuff
                        try {
                            JSONObject rootObject = parseJson(result);
                            setValues(rootObject);
                        } catch (ParseException e) {
                            throw new RuntimeException(e);
                        }

//                        TextView vv_weatherIcon = (TextView)findViewById(R.id.vv_weatherIcon);
//                        vv_weatherIcon.setText(jsonString);
                    }
                });

            }
        }).start();
    }
    private String downloadUrl(String urlString){
        try {
            String result = "HTTPS error";
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//            conn.setRequestMethod("GET");
            conn.connect();

            int responseCode = conn.getResponseCode();
            if(responseCode != 200){
                throw new RuntimeException("HttpResponseCode: " + responseCode);
            }
            else{
                StringBuilder infoString = new StringBuilder();
                Scanner objectGrabber = new Scanner(url.openStream());

                while(objectGrabber.hasNext()){
                    infoString.append(objectGrabber.nextLine());
                }
                objectGrabber.close();
                result = infoString.toString();
                return result;
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public JSONObject parseJson(String jsonString) throws ParseException {
        JSONParser parser = new JSONParser();
        JSONObject jsonRootObject = (JSONObject) parser.parse(jsonString);
        return jsonRootObject;
    }

    public void setValues(JSONObject origJsonObject){

        JSONArray jsonObjArray = (JSONArray) origJsonObject.get("list");
        JSONObject jsonRootObject = ((JSONObject) jsonObjArray.get(0));
        JSONObject day1Object = ((JSONObject) jsonObjArray.get(1));
        JSONObject day2Object = ((JSONObject) jsonObjArray.get(2));
        JSONObject day3Object = ((JSONObject) jsonObjArray.get(3));

        //set weather condition to whatever condition api returned
        JSONArray jsonWeatherArray = (JSONArray) jsonRootObject.get("weather");
        String cond = ((JSONObject) jsonWeatherArray.get(0)).get("main").toString();
        setCurrentCondition(cond);


        int weatherId = Integer.parseInt(((JSONObject) jsonWeatherArray.get(0)).get("id").toString());
        char currentWeatherIcon = findSymbol(weatherId);
        setCurrentWeatherIcon(currentWeatherIcon);

        //set current city name
        JSONObject city = (JSONObject) origJsonObject.get("city");
        String cityName = city.get("name").toString();
        setCityName(cityName);

        JSONObject jsonMainObject = (JSONObject) jsonRootObject.get("main");
        double currentTemp = Double.parseDouble(jsonMainObject.get("temp").toString());
        double highTemp = Double.parseDouble(jsonMainObject.get("temp_max").toString());
        double lowTemp = Double.parseDouble(jsonMainObject.get("temp_min").toString());


        currentTemp = Math.ceil(currentTemp);
        setCurrentTemp(currentTemp);
        setBgColor((int)currentTemp);
        highTemp = Math.ceil(highTemp);
        setHighTemp(highTemp);
        lowTemp = Math.ceil(lowTemp);
        setLowTemp(lowTemp);


        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            LocalDate today = LocalDate.now();
            LocalDate nextDay = today.plusDays(1);
            DayOfWeek dayOfWeek = nextDay.getDayOfWeek();
            setDay1(dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()));
            nextDay =  nextDay.plusDays(1);
            dayOfWeek = nextDay.getDayOfWeek();
            setDay2(dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()));
            nextDay =  nextDay.plusDays(1);
            dayOfWeek = nextDay.getDayOfWeek();
            setDay3(dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()));
        }





        JSONArray day1WeatherArray = (JSONArray) day1Object.get("weather");
        JSONArray day2WeatherArray = (JSONArray) day2Object.get("weather");
        JSONArray day3WeatherArray = (JSONArray) day3Object.get("weather");
        int day1WeatherId = Integer.parseInt(((JSONObject) day1WeatherArray.get(0)).get("id").toString());
        int day2WeatherId = Integer.parseInt(((JSONObject) day2WeatherArray.get(0)).get("id").toString());
        int day3WeatherId = Integer.parseInt(((JSONObject) day3WeatherArray.get(0)).get("id").toString());
        char day1Icon = findSymbol(day1WeatherId);
        char day2Icon = findSymbol(day2WeatherId);
        char day3Icon = findSymbol(day3WeatherId);
        setDay1Icon(day1Icon);
        setDay2Icon(day2Icon);
        setDay3Icon(day3Icon);
    }

    public char findSymbol(int id){
        if(id >= 200 && id <=232){
            return 'F';
        }
        else if(id >= 300 && id <=321){
            return '-';
        }
        else if(id >= 500 && id <=531){
            return '$';
        }
        //
        else if(id >= 600 && id <=622){
            return'9';
        }
        //atmosphere
        else if(id >= 700 && id <=781){
            return '<';
        }
        //clear
        else if(id == 800){
            return 'I';
        }
        //clouds
        else if(id >= 801 && id <=804){
            return '!';
        }

        return ' ';

    }
//    enum icons{
//        ClimaconCloud                   = '!',
//        ClimaconCloudSun                = '"',
//        ClimaconCloudMoon               = '#',
//
//        ClimaconRain                    = '$',
//        ClimaconRainSun                 = '%',
//        ClimaconRainMoon                = '&',
//
//        ClimaconRainAlt                 = '\'',
//        ClimaconRainSunAlt              = '(',
//        ClimaconRainMoonAlt             = ')',
//
//        ClimaconDownpour                = '*',
//        ClimaconDownpourSun             = '+',
//        ClimaconDownpourMoon            = ',',
//
//        ClimaconDrizzle                 = '-',
//        ClimaconDrizzleSun              = '.',
//        ClimaconDrizzleMoon             = '/',
//
//        ClimaconSleet                   = '0',
//        ClimaconSleetSun                = '1',
//        ClimaconSleetMoon               = '2',
//
//        ClimaconHail                    = '3',
//        ClimaconHailSun                 = '4',
//        ClimaconHailMoon                = '5',
//
//        ClimaconFlurries                = '6',
//        ClimaconFlurriesSun             = '7',
//        ClimaconFlurriesMoon            = '8',
//
//        ClimaconSnow                    = '9',
//        ClimaconSnowSun                 = ':',
//        ClimaconSnowMoon                = ';',
//
//        ClimaconFog                     = '<',
//        ClimaconFogSun                  = '=',
//        ClimaconFogMoon                 = '>',
//
//        ClimaconHaze                    = '?',
//        ClimaconHazeSun                 = '@',
//        ClimaconHazeMoon                = 'A',
//
//        ClimaconWind                    = 'B',
//        ClimaconWindCloud               = 'C',
//        ClimaconWindCloudSun            = 'D',
//        ClimaconWindCloudMoon           = 'E',
//
//        ClimaconLightning               = 'F',
//        ClimaconLightningSun            = 'G',
//        ClimaconLightningMoon           = 'H',
//
//        ClimaconSun                     = 'I',
//        ClimaconSunset                  = 'J',
//        ClimaconSunrise                 = 'K',
//        ClimaconSunLow                  = 'L',
//        ClimaconSunLower                = 'M',
//
//        ClimaconMoon                    = 'N',
//        ClimaconMoonNew                 = 'O',
//        ClimaconMoonWaxingCrescent      = 'P',
//        ClimaconMoonWaxingQuarter       = 'Q',
//        ClimaconMoonWaxingGibbous       = 'R',
//        ClimaconMoonFull                = 'S',
//        ClimaconMoonWaningGibbous       = 'T',
//        ClimaconMoonWaningQuarter       = 'U',
//        ClimaconMoonWaningCrescent      = 'V',
//
//        ClimaconSnowflake               = 'W',
//        ClimaconTornado                 = 'X',
//
//        ClimaconThermometer             = 'Y',
//        ClimaconThermometerLow          = 'Z',
//        ClimaconThermometerMediumLoew   = '[',
//        ClimaconThermometerMediumHigh   = '\\',
//        ClimaconThermometerHigh         = ']',
//        ClimaconThermometerFull         = '^',
//        ClimaconCelsius                 = '_',
//        ClimaconFahrenheit              = '\'',
//        ClimaconCompass                 = 'a',
//        ClimaconCompassNorth            = 'b',
//        ClimaconCompassEast             = 'c',
//        ClimaconCompassSouth            = 'd',
//        ClimaconCompassWest             = 'e',
//
//        ClimaconUmbrella                = 'f',
//        ClimaconSunglasses              = 'g',
//
//        ClimaconCloudRefresh            = 'h',
//        ClimaconCloudUp                 = 'i',
//        ClimaconCloudDown               = 'j'
//    }



    public int getBgColor() {
        return bgColor;
    }

    public void setBgColor(int temp) {

        if(temp <= 17){
            this.bgColor = android.R.color.holo_blue_dark;
        }
        else if(temp >=18 && temp <= 34){
            this.bgColor = android.R.color.holo_blue_light;
        }
        else if(temp >=35 && temp <= 51){
            this.bgColor = android.R.color.holo_blue_bright;
        }
        else if(temp >=52 && temp <= 68){
            this.bgColor = android.R.color.holo_purple;
        }
        else if(temp >=69 && temp <= 85){
            this.bgColor = android.R.color.holo_red_light;
        }
        else {
            this.bgColor = android.R.color.holo_red_dark;
        }


    }

    public void setCurrentWeatherIcon(char currentWeatherIcon) {
        this.currentWeatherIcon = currentWeatherIcon;
    }
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public void setCurrentTemp(double currentTemp) {
        this.currentTemp = currentTemp;
    }

    public void setHighTemp(double highTemp) {
        this.highTemp = highTemp;
    }

    public void setLowTemp(double lowTemp) {
        this.lowTemp = lowTemp;
    }

    public void setDay1(String day1) {
        this.day1 = day1;
    }

    public void setDay2(String day2) {
        this.day2 = day2;
    }

    public void setDay3(String day3) {
        this.day3 = day3;
    }

    public void setDay1Icon(char day1Icon) {
        this.day1Icon = day1Icon;
    }

    public void setDay2Icon(char day2Icon) {
        this.day2Icon = day2Icon;
    }

    public void setDay3Icon(char day3Icon) {
        this.day3Icon = day3Icon;
    }

    public void setCurrentCondition(String currentCondition) {
        this.currentCondition = currentCondition;
    }
}
