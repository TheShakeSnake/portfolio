package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import com.tbuonomo.viewpagerdotsindicator.SpringDotsIndicator;




public class MainActivity extends AppCompatActivity {

CityModel[] cities = {
        new CityModel(48197),
        new CityModel(85365),
        new CityModel(99703),
        new CityModel(43078),
        new CityModel(49668)
};



    private ViewPager2 viewPager2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        viewPager2 = findViewById(R.id.viewpager);
        viewPager2.setAdapter(new ViewPager2Adapter(cities));

        SpringDotsIndicator springDotsIndicator = (SpringDotsIndicator) findViewById(R.id.spring_dots_indicator);
        springDotsIndicator.setViewPager2(viewPager2);

//"https://api.openweathermap.org/data/2.5/weather?zip=48197,us&appid=e19ece920b9ab597096cd1e9c0b3ea99"


    }



}