package com.example.weatherapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class ViewPager2Adapter  extends RecyclerView.Adapter<ViewPager2Adapter.MyViewHolder> {

    private CityModel[] models;

    static boolean celcius = false;
    boolean ready = false;
   Object sharedObject;

    ViewPager2Adapter(CityModel[] models) {this.models = models;}

    @NonNull
    @Override
    public ViewPager2Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.weather_display, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewPager2Adapter.MyViewHolder holder, int position) {


        holder.vv_weatherIcon.setText(models[position].getCurrentWeatherIcon() + "");
        holder.vv_weatherName.setText(models[position].getCurrentCondition());
        holder.vv_cityName.setText(models[position].getCityName());
        holder.vv_temp.setText((int)models[position].getCurrentTemp() + "\u00B0");
        holder.vv_highTemp.setText("H " + (int)models[position].getHighTemp() + "");
        holder.vv_lowTemp.setText("L " + (int)models[position].getLowTemp() + "");
        holder.vv_day1.setText(models[position].getDay1());
        holder.vv_day2.setText(models[position].getDay2());
        holder.vv_day3.setText(models[position].getDay3());
        holder.vv_day1Icon.setText(models[position].getDay1Icon() + "");
        holder.vv_day2Icon.setText(models[position].getDay2Icon() + "");
        holder.vv_day3Icon.setText(models[position].getDay3Icon() + "");
        holder.constraintlayout.setBackgroundResource(models[position].getBgColor());

        holder.unitButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(!celcius){
                            double currentTemp = models[position].getCurrentTemp();
                            double highTemp = models[position].getHighTemp();
                            double lowTemp = models[position].getLowTemp();

                            currentTemp = (5.0/9.0)*(currentTemp - 32.0);
                            highTemp = (5.0/9.0)*(highTemp - 32.0);
                            lowTemp = (5.0/9.0)*(lowTemp - 32.0);


                            holder.vv_highTemp.setText("H " + (int)highTemp);
                            holder.vv_temp.setText((int)currentTemp + "\u00B0");
                            holder.vv_lowTemp.setText("L " + (int)lowTemp);


                                    celcius = true;
                                    holder.unitButton.setText("C");
                        }
                        else{
                            holder.vv_temp.setText((int)models[position].getCurrentTemp() + "\u00B0");
                            holder.vv_highTemp.setText("H " + (int)models[position].getHighTemp() + "");
                            holder.vv_lowTemp.setText("L " + (int)models[position].getLowTemp() + "");

                            celcius = false;
                            holder.unitButton.setText("F");
                        }
                    }
                }
        );

        System.out.println(position);
    }

    @Override
    public int getItemCount() {
        return models.length;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView vv_weatherIcon;
        TextView vv_weatherName;
        TextView vv_cityName;
        TextView vv_temp;
        TextView vv_highTemp;
        TextView vv_lowTemp;
        TextView vv_day1;
        TextView vv_day2;
        TextView vv_day3;
        TextView vv_day1Icon;
        TextView vv_day2Icon;
        TextView vv_day3Icon;
        Typeface weatherSymbols;
        Typeface appleFont;

        Button unitButton;
        ConstraintLayout constraintlayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            vv_weatherIcon = itemView.findViewById(R.id.vv_weatherIcon);
            vv_weatherName = itemView.findViewById(R.id.vv_weatherName);
            vv_cityName = itemView.findViewById(R.id.vv_cityName);
            vv_temp = itemView.findViewById(R.id.vv_temp);
            vv_highTemp = itemView.findViewById(R.id.vv_highTemp);
            vv_lowTemp = itemView.findViewById(R.id.vv_lowTemp);
            vv_day1 = itemView.findViewById(R.id.vv_day1);
            vv_day2 = itemView.findViewById(R.id.vv_day2);
            vv_day3 = itemView.findViewById(R.id.vv_day3);
            vv_day1Icon = itemView.findViewById(R.id.vv_day1Icon);
            vv_day2Icon = itemView.findViewById(R.id.vv_day2Icon);
            vv_day3Icon = itemView.findViewById(R.id.vv_day3Icon);
            unitButton = itemView.findViewById(R.id.button);
            weatherSymbols = ResourcesCompat.getFont(itemView.getContext(), R.font.climacons);
            appleFont = ResourcesCompat.getFont(itemView.getContext(), R.font.helveticaneue_thin);

            //set font of main weather icon to weather symbols
            vv_weatherIcon.setTypeface(weatherSymbols);
            //make big
            vv_weatherIcon.setTextSize(TypedValue.COMPLEX_UNIT_SP,225);
            vv_weatherName.setTextSize(TypedValue.COMPLEX_UNIT_SP,75);

            //set all text views to use the apple font
            vv_weatherName.setTypeface(appleFont);
            vv_cityName.setTypeface(appleFont);
            vv_day1.setTypeface(appleFont);
            vv_day2.setTypeface(appleFont);
            vv_day3.setTypeface(appleFont);
            vv_temp.setTypeface(appleFont);
            vv_highTemp.setTypeface(appleFont);
            vv_lowTemp.setTypeface(appleFont);

            //set all other icon views to use the weather icons
            vv_day1Icon.setTypeface(weatherSymbols);
            vv_day2Icon.setTypeface(weatherSymbols);
            vv_day3Icon.setTypeface(weatherSymbols);
            //make larger
            vv_day1Icon.setTextSize(TypedValue.COMPLEX_UNIT_SP,50);
            vv_day2Icon.setTextSize(TypedValue.COMPLEX_UNIT_SP,50);
            vv_day3Icon.setTextSize(TypedValue.COMPLEX_UNIT_SP,50);

            constraintlayout = itemView.findViewById(R.id.constraintlayout);

        }
    }
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//    }
}