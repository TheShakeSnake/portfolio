class Employee{
    constructor(id,firstName,lastName,email,password,manager,organizaiton)
    {
        this.id=id;
        this.firstName=firstName;
        this.lastName=lastName;
        this.email=email;
        this.password=password;
        this.organizaiton=organizaiton;
        this.manager=manager;
    }
}
export default Employee;