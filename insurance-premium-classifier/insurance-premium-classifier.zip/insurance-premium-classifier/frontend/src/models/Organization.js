class Oranization{
    constructor(id,name,address,manager,organizaiton)
    {
        this.id=id;
        this.address=address;
        this.firstName=firstName;
        this.lastName=lastName;
        this.organizaiton=organizaiton;
        this.manager=manager;
    }
}
export default Organization;