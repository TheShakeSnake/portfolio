class Client{
    constructor(id,address,firstName,lastName,email,password,dob,employee,vehicles,payments)
    {
        this.id=id;
        this.address=address;
        this.firstName=firstName;
        this.lastName=lastName;
        this.email=email
        this.dob=dob;
        this.password=password;
        this.employee=employee;
        this.vehicles=vehicles;
        this.payments=payments;
    }
}
export default Client;