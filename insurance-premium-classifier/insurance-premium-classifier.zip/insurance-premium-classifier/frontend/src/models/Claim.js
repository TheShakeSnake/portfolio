class Claim{
    constructor(id,claimDate,client,vehicle)
    {
        this.id=id;
        this.claimDate=claimDate;
        this.client=client;
        this.vehicle=vehicle;
    }
}
export default Claim;