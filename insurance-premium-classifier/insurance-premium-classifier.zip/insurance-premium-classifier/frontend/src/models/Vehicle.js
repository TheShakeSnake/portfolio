class Vehicle{
    constructor(id,vin,make,model,year,miles,plate)
    {
        this.id=id;
        this.vin=vin;
        this.make=make;
        this.model=model;
        this.year=year;
        this.miles=miles;
        this.plate=plate;
    }
}
export default Vehicle;