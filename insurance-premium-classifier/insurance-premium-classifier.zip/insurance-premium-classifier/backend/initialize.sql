use car_insurance;

insert into client(first_name, last_name, address, email, password)
VALUES ('sean', 'polidori', '111 address', 'dev@gmail.com', '$2a$10$6i9BCGvDJp.TnAYFOJhkyO7l5lHHmysPWmFZP6eH9L5.lsR0Lkzh6');