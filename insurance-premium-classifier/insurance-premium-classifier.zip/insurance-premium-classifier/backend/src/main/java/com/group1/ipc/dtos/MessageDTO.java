package com.group1.ipc.dtos;

public class MessageDTO {

	private String message;
	
	public MessageDTO(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
	
}
