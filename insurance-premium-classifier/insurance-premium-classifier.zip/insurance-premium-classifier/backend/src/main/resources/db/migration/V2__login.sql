ALTER TABLE client
ADD email varchar(100);

ALTER TABLE client
ADD password varchar(200);

ALTER TABLE client
ADD dob DATE;

ALTER TABLE employee
ADD email varchar(100);

ALTER TABLE employee
ADD password varchar(200);