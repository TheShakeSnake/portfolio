import java.util.Random;

public class SystemFour {
	   private SinglyLinkedQueue queue1;           //first server queue
	   private SinglyLinkedQueue queue2;           //second server queue
	   private int arrivalRate;                   //arrival rate
	   private int serviceRate;                   //service rate
	   private int simulationTime;                //simulation time
	   private Random generator;                  //random number generator

	   //constructor of queueing system
	   public SystemFour(int serviceRate, int arrivalRate, 
	   int simulationTime, int seed)
	   {
		   //create empty queue, initialize rates, initialize simulaion
		   //time, create random number generator
	       queue1 = new SinglyLinkedQueue();
	       queue2 = new SinglyLinkedQueue();
	       this.serviceRate = serviceRate;     
	       this.arrivalRate = arrivalRate;
	       this.simulationTime = simulationTime;
	       generator = new Random(seed);  
	   }

	   //simulation of queueing system
	   public void run()
	   {
	       boolean server1Free = true; //server1 (free/occupied)
	       boolean server2Free = true; //server2 (free/occupied)
	       int arrivalTime;           //arrival time of customer
	       int waitTime;              //wait time of customer
	       int serviceTime1 = 0;      //remaining service time of customer taken by server1
	       int serviceTime2 = 0;	  //remaining service time of customer taken by server2
	       int totalWait = 0;         //total wait time of cutomers
	       int custServed = 0;        //total customers served
	       int queueSize = 0;         //number of customers in queue
		   
	       //simulation loop
	       for (int i = 0; i < simulationTime; i++)
	       {
	    	   //if a customer arrives then add the customer to the queue
	           if (generator.nextDouble() < 1.0/arrivalRate)
	        	   //new customers always join the smaller of the two queues
	        	   if(queue2.size() < queue1.size()) {
	        		   queue2.enqueue(i);
	        	   }
	        	   else
	        		   queue1.enqueue(i);                         

	           //if server is free and a customer is waiting
	           if (server1Free && !queue1.isEmpty())
	           {                                 
	        	   //remove customer from queue
	               arrivalTime = (Integer)queue1.dequeue();
	               //find waiting time
	               waitTime = i - arrivalTime;     
	               //update total wait time
	               totalWait = totalWait + waitTime;
	               //customer goes to server
	               server1Free = false;      
	               //customer gets service time
	               serviceTime1 = generator.nextInt(serviceRate) + 1;
	           }                              

	           //if server is occupied
	           if (!server1Free)
	           {
	        	   //decrease the service time
	               serviceTime1 = serviceTime1 - 1;
	               //if server finishes serving the customer
	               if (serviceTime1 == 0)
	               {
	            	  //update total customers served
	                  custServed = custServed + 1;
	                  //server becomes free
	                  server1Free = true;
	               }
	           }
	           //if server is free and a customer is waiting
	           if (server2Free && !queue2.isEmpty())
	           {                                 
	        	   //remove customer from queue
	               arrivalTime = (Integer)queue2.dequeue();
	               //find waiting time
	               waitTime = i - arrivalTime;     
	               //update total wait time
	               totalWait = totalWait + waitTime;
	               //customer goes to server
	               server2Free = false;      
	               //customer gets service time
	               serviceTime2 = generator.nextInt(serviceRate) + 1;
	           }                              

	           //if server is occupied
	           if (!server2Free)
	           {
	        	   //decrease the service time
	               serviceTime2 = serviceTime2 - 1;
	               //if server finishes serving the customer
	               if (serviceTime2 == 0)
	               {
	            	  //update total customers served
	                  custServed = custServed + 1;
	                  //server becomes free
	                  server2Free = true;
	               }
	           }
			   
			   //find current queue size
			   queueSize = queueSize + queue1.size() + queue2.size();
	       }

	       //print customers served, average wait time, average queue size, 
		   //and customers left in queue
	       System.out.println("Number of customers served: " + custServed);
	       System.out.println("Average waiting time: "
	                          + totalWait/(double)custServed);
		   System.out.println("Average queue size: " 
		                      + queueSize/(double)simulationTime);
		   System.out.println("Customers left in queue: " + (queue1.size() + queue2.size()));
	       System.out.println();
	   }
}
