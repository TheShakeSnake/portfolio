import java.util.Random;

public class SystemTwo {
	   private SinglyLinkedQueue queue1;          //first queue
	   private SinglyLinkedQueue queue2;		  //second queue
	   private int arrivalRate;                   //arrival rate
	   private int serviceRate;                   //service rate
	   private int simulationTime;                //simulation time
	   private Random generator;                  //random number generator

	   //constructor of queueing system
	   public SystemTwo(int serviceRate, int arrivalRate, 
	   int simulationTime, int seed)
	   {
		   //create empty queues, initialize rates, initialize simulaion
		   //time, create random number generator
	       queue1 = new SinglyLinkedQueue();
	       queue2 = new SinglyLinkedQueue();
	       this.serviceRate = serviceRate;     
	       this.arrivalRate = arrivalRate;
	       this.simulationTime = simulationTime;
	       generator = new Random(seed);  
	   }
	   
	   public void run()
	   {
	       boolean serverFree = true; //server (free/occupied)
	       boolean serverchoice = true;	// used to alternate between queues
	       int arrivalTime;           //arrival time of customer
	       int waitTime;              //wait time of customer
	       int serviceTime = 0;       //remaining service time of customer
	       int totalWait = 0;         //total wait time of customers
	       int custServed = 0;        //total customers served
	       int queue1Size = 0;        //number of customers in queue1
	       int queue2Size = 0;		  //number of customers in queue2
		   
	       //simulation loop
	       for (int i = 0; i < simulationTime; i++)
	       {
	    	   //if a customer arrives then add the customer to the queue
	           if (generator.nextDouble() < 1.0/arrivalRate) {
	        	   //new customers always join the smaller of the two queues
	        	   if(queue2.size() < queue1.size()) {
	        		   queue2.enqueue(i);
	        	   }
	        	   else
	        		   queue1.enqueue(i);
	           }
	        	   //if queue1 is empty, pick customer from queue2
	           if(queue1.isEmpty())
	        	   serverchoice = false;
	           	  //if queue2 is empty, pick a customer from queue1
	           if(queue2.isEmpty())
	        	   serverchoice = true;
	                                   
	           //if serverchioce is true, pick customer from queue1
	          if(serverchoice){
	           //if server is free and a customer is waiting in queue1
	           if (serverFree && !queue1.isEmpty())
	           {                                 
	        	   //remove customer from queue
	               arrivalTime = (Integer)queue1.dequeue();
	               //find waiting time
	               waitTime = i - arrivalTime;     
	               //update total wait time
	               totalWait = totalWait + waitTime;
	               //customer goes to server
	               serverFree = false;      
	               //customer gets service time
	               serviceTime = generator.nextInt(serviceRate) + 1;
	           }                              

	           //if server is occupied
	           if (!serverFree)
	           {
	        	   //decrease the service time
	               serviceTime = serviceTime - 1;
	               //if server finishes serving the customer
	               if (serviceTime == 0)
	               {
	            	  //update total customers served
	                  custServed = custServed + 1;
	                  //server becomes free
	                  serverFree = true;
	                  //change serverchoice to false to alternate to queue2 on next run
		        	  serverchoice = false;
	               }
	           }
			   
			   //find current queue size
			   queue1Size = queue1Size + queue1.size();
	       }
	          // if serverchoice is false, take a customer from queue2
	          else {
	           //if server is free and a customer is waiting in queue2
	           if (serverFree && !queue2.isEmpty())
	           {                                 
	        	   //remove customer from queue
	               arrivalTime = (Integer)queue2.dequeue();
	               //find waiting time
	               waitTime = i - arrivalTime;     
	               //update total wait time
	               totalWait = totalWait + waitTime;
	               //customer goes to server
	               serverFree = false;      
	               //customer gets service time
	               serviceTime = generator.nextInt(serviceRate) + 1;
	           }                              

	           //if server is occupied
	           if (!serverFree)
	           {
	        	   //decrease the service time
	               serviceTime = serviceTime - 1;
	               //if server finishes serving the customer
	               if (serviceTime == 0)
	               {
	            	  //update total customers served
	                  custServed = custServed + 1;
	                  //server becomes free
	                  serverFree = true;
		        	  //change serverchoice to true to alternate to queue1 on next run
		        	  serverchoice = true;
	               }
	           }
			   
			   //find current queue size
			   queue2Size = queue2Size + queue2.size();
	       }
	          }
	       

	       //print customers served, average wait time, average queue size, 
		   //and customers left in queue
	       System.out.println("Number of customers served: " + custServed);
	       System.out.println("Average waiting time: "
	                          + totalWait/(double)custServed);
		   System.out.println("Average queue size: " 
		                      + (queue1Size + queue2Size)/(double)simulationTime);
		   System.out.println("Customers left in queue: " + (queue1.size() + queue2.size()));
	       System.out.println();
	   }
}
