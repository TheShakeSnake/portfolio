import java.util.Random;

public class SystemThree {
	   private SinglyLinkedQueue queue;           //queue
	   private int arrivalRate;                   //arrival rate
	   private int serviceRate;                   //service rate
	   private int simulationTime;                //simulation time
	   private Random generator;                  //random number generator

	   //constructor of queueing system
	   public SystemThree(int serviceRate, int arrivalRate, 
	   int simulationTime, int seed)
	   {
		   //create empty queue, initialize rates, initialize simulaion
		   //time, create random number generator
	       queue = new SinglyLinkedQueue();   
	       this.serviceRate = serviceRate;     
	       this.arrivalRate = arrivalRate;
	       this.simulationTime = simulationTime;
	       generator = new Random(seed);  
	   }

	   //simulation of queueing system
	   public void run()
	   {
	       boolean server1Free = true; //server1 (free/occupied)
	       boolean server2Free = true; //server2 (free/occupied)
	       int arrivalTime;           //arrival time of customer
	       int waitTime;              //wait time of customer
	       int serviceTime1 = 0;      //remaining service time of customer who takes server1
	       int serviceTime2 = 0;	  //remaining service time of customer who takes server2 
	       int totalWait = 0;         //total wait time of cutomers
	       int custServed = 0;        //total customers served
	       int queueSize = 0;         //number of customers in queue
		   
	       //simulation loop
	       for (int i = 0; i < simulationTime; i++)
	       {
	    	   //if a customer arrives then add the customer to the queue
	           if (generator.nextDouble() < 1.0/arrivalRate)
	              queue.enqueue(i);
	           
	           //if both servers are free and there are customers in the queue
	           if(server1Free && server2Free && !queue.isEmpty()) {
	        	   //customer picks a server at random, picks server1 if random is below 0.5
	        	   if(generator.nextDouble() < 0.5) {
		        	   //remove customer from queue
		               arrivalTime = (Integer)queue.dequeue();
		               //find waiting time
		               waitTime = i - arrivalTime;     
		               //update total wait time
		               totalWait = totalWait + waitTime;
		               //customer goes to server1
		               server1Free = false;      
		               //customer gets service time
		               serviceTime1 = generator.nextInt(serviceRate) + 1;
	        	   }
	        	   //server2 if above 0.5
	        	   else {
		        	   //remove customer from queue
		               arrivalTime = (Integer)queue.dequeue();
		               //find waiting time
		               waitTime = i - arrivalTime;     
		               //update total wait time
		               totalWait = totalWait + waitTime;
		               //customer goes to server2
		               server2Free = false;      
		               //customer gets service time
		               serviceTime2 = generator.nextInt(serviceRate) + 1;
	        	   }
	           }
	           
	           //if only server1 is free, customer takes server1
	            if(server1Free && !queue.isEmpty()) {
		        	   //remove customer from queue
		               arrivalTime = (Integer)queue.dequeue();
		               //find waiting time
		               waitTime = i - arrivalTime;     
		               //update total wait time
		               totalWait = totalWait + waitTime;
		               //customer goes to server1
		               server1Free = false;      
		               //customer gets service time
		               serviceTime1 = generator.nextInt(serviceRate) + 1;
	           }
	           //if only server2 is free, customer takes server2
	            if(server2Free && !queue.isEmpty()) {
		        	   //remove customer from queue
		               arrivalTime = (Integer)queue.dequeue();
		               //find waiting time
		               waitTime = i - arrivalTime;     
		               //update total wait time
		               totalWait = totalWait + waitTime;
		               //customer goes to server
		               server2Free = false;      
		               //customer gets service time
		               serviceTime2 = generator.nextInt(serviceRate) + 1;
	           }

                       

	           //if server1 is occupied
	           if (!server1Free)
	           {
	        	   //decrease the service time
	               serviceTime1 = serviceTime1 - 1;
	               //if server finishes serving the customer
	               if (serviceTime1 == 0)
	               {
	            	  //update total customers served
	                  custServed = custServed + 1;
	                  //server becomes free
	                  server1Free = true;
	               }
	           }
	           //if server2 is occupied
	           if (!server2Free)
	           {
	        	   //decrease the service time
	               serviceTime2 = serviceTime2 - 1;
	               //if server finishes serving the customer
	               if (serviceTime2 == 0)
	               {
	            	  //update total customers served
	                  custServed = custServed + 1;
	                  //server becomes free
	                  server2Free = true;
	               }
	           }
			   
			   //find current queue size
			   queueSize = queueSize + queue.size();
	       }

	       //print customers served, average wait time, average queue size, 
		   //and customers left in queue
	       System.out.println("Number of customers served: " + custServed);
	       System.out.println("Average waiting time: "
	                          + totalWait/(double)custServed);
		   System.out.println("Average queue size: " 
		                      + queueSize/(double)simulationTime);
		   System.out.println("Customers left in queue: " + queue.size());
	       System.out.println();
	   }

}
