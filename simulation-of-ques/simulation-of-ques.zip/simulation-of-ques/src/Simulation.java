import java.util.Scanner;
public class Simulation {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int choice = 0, service = 0, arrival = 0, time = 0, seed = 0;
		boolean correct = false;
		
		System.out.println("How many itterations would you like to run? (enter a positive integer)");
		time = input.nextInt();
		System.out.println("What would you like the arrival value to be? (enter a positive integer)");
		arrival = input.nextInt();
		System.out.println("What would you like the service value to be? (enter a positive integer");
		service = input.nextInt();
		System.out.println("What would you like the seed to be? (enter a positive integer)");
		seed = input.nextInt();
		System.out.println("Which system would you like to simulate?:\n 1.Single server/single queue\n 2. Single server/multiple queues\n 3. Multiple server/single queue\n 4. Multiple server/multiple queue");
		choice = input.nextInt();
		while(!correct)
		switch(choice) {
		case 1: {
			correct = true;
			SystemOne sim = new SystemOne(service, arrival, time, seed);
			sim.run();
			break;
		}
		case 2:{
			correct = true;
			SystemTwo sim = new SystemTwo(service, arrival, time, seed);
			sim.run();
			break;
		}
		case 3:{
			correct = true;
			SystemThree sim = new SystemThree(service, arrival, time, seed);
			sim.run();
			break;
		}
		case 4: {
			correct = true;
			SystemFour sim = new SystemFour(service, arrival, time, seed);
			sim.run();
			break;
		}
			default: System.out.println("invalid choice, try again");
		}

	}

}
