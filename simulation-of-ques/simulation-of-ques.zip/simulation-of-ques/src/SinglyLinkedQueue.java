import java.util.NoSuchElementException;

//Queue data structure using singly linked list with head and tail
public class SinglyLinkedQueue
{
   //node class (inner class)
   private class Node
   {
      private Object data;    //data of node
	  private Node next;      //link to next node
	  
	  //constructor of node
	  private Node(Object data, Node next)
	  {
	     this.data = data;
	     this.next = next;
	  }
   }
   
   private Node head;      //head of queue
   private Node tail;      //tail of queue
   private int size;       //size of queue
   
   //constructor of queue
   public SinglyLinkedQueue()
   {
      head = tail = null;
	  size = 0;
   }
  
   //adds at the end of queue
   public void enqueue(Object data)
   {
      if (head == null)                          //empty list
    	 head = tail = new Node(data, null);
      else                                       //nonempty list
      {
    	 tail.next = new Node(data, null);
    	 tail = tail.next;
      }
      
      size = size + 1;                         
   }
   
   //removes from the front of queue
   public Object dequeue()
   {
      if (isEmpty())                           
    	 throw new NoSuchElementException();
      
      Object data = head.data;
      
      if (head == tail)              //queue has one node
    	 head = tail = null;
      else                           //queue has more than one node
    	 head = head.next;
      
      size = size - 1;
      return data;
   }
   
   //accesses the front of queue
   public Object peek()
   {
	  if (isEmpty())
	     throw new NoSuchElementException();
	  
	  return head.data;
   }
   
   //checks whether queue is empty
   public boolean isEmpty()
   {
	  return (size == 0);
   }
   
   //finds size of queue
   public int size()
   {
	  return size;
   }
}
